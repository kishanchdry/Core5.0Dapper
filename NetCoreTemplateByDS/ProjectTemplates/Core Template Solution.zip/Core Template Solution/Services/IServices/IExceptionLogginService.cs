﻿using $safeprojectname$.Shared.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$.Services.IServices
{
    public interface IExceptionLogginService// : IGenericService<ExceptionModel>
    {
        bool SaveException(Exception model);
        bool SaveException(ExceptionModel model);
    }
}
